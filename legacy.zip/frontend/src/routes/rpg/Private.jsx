export default function Private() {
  
};